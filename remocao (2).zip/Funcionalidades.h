#ifndef FUNC_H
    #define FUNC_H
    
    void ler_entradas();
#endif