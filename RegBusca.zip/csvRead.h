#ifndef csvRead_H
    #define csvRead_H
    #include <stdbool.h>
    
    bool csv_to_bin(char* arqcsv,char*arqbin);








#endif