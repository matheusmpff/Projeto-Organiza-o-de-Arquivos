#ifndef csvRead_H
    #define csvRead_H
    #include <stdbool.h>
    
    bool CSV_to_BIN(char* nomecsv, char* nomeBin);








#endif