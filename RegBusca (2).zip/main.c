#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "RegRW.h"
#include "RegPrint.h"
#include "RegBusca.h"
#include "csvRead.h"
#include "Funcionalidades.h"


int main(){
    ler_entradas();
}