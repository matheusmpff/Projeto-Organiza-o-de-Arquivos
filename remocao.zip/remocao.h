#ifndef REMOVIDO_H
    #define REMOVIDO_H

    #include "RegRW.H"

    void remover_registros(char * nomebin, char* campos[], char* valores[], int tamanho);

#endif