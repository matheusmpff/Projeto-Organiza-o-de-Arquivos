#ifndef FUNC_H
    #define FUNC_H
    
    void ler_entradas();
    void scan_quote_string(char *str);
    void binarioNaTela(char *nomeArquivoBinario);
#endif